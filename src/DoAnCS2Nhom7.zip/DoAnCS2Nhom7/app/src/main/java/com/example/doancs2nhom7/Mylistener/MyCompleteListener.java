package com.example.doancs2nhom7.Mylistener;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();
}
