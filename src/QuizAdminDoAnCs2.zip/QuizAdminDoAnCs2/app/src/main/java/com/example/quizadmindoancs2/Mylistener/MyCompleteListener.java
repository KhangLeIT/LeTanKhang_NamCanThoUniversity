package com.example.quizadmindoancs2.Mylistener;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();
}
